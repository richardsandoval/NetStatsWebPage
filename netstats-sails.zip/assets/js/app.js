/**
 * Created by rsandoval on 07/12/15.
 */
'use strict';

angular.module('app', [
    'chart.js',
    'angularMoment',
    '720kb.datepicker',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ngStorage',
    'ui.router',
    'ui.bootstrap',
    'ui.utils',
    'ui.load',
    'ui.jq',
    'oc.lazyLoad',
    'pascalprecht.translate'
]);